/**
  Copyright (c) 2015, 2020, Oracle and/or its affiliates.
  The Universal Permissive License (UPL), Version 1.0
*/
define({
  "root": {
    "my-first-component" : {
    		"sampleString": "The strings file can be used to manage translatable resources"
    }
  }
});